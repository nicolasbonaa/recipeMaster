# Manual de Testes - Atividade 05

Os testes abaixo devem ser executados depois que o MySQL, o backend e o frontend estiverem ativos. Eles nao foram executados nesta etapa.

## 1. Preparar os servidores

### Backend

Na raiz do projeto:

```powershell
npm run dev
```

API esperada:

```text
http://localhost:3000/api
```

### Frontend

Em outro terminal:

```powershell
cd recipeMaster-frontend
npm run dev
```

Frontend esperado:

```text
http://localhost:5173
```

Use um usuario valido ja cadastrado e faca login pelo frontend. O token sera salvo na chave `recipeMaster_token` do Local Storage.

## 2. Testar o carregamento do perfil

1. Abra a Landing Page.
2. Clique em `Entrar`.
3. Faca login.
4. Clique em `Meu perfil` na Navbar.
5. Confirme que nome, bio e foto carregam com dados reais.
6. Abra o Console e confirme a mensagem:

```text
Perfil autenticado OK:
```

Para a entrega, salve um print como `perfil-carregado.jpg`.

## 3. Testar preview local sem rede

1. Na tela `Meu perfil`, abra a aba `Network` do DevTools.
2. Limpe as requisicoes atuais.
3. Clique em `Escolher foto`.
4. Selecione uma imagem.
5. Confirme que a imagem muda imediatamente na tela.
6. Confirme que nenhuma requisicao `PUT /api/profile/me` foi criada apenas por escolher a foto.

O preview usa `URL.createObjectURL`, por isso a imagem aparece localmente antes do envio.

Para a entrega, salve um print como `preview-local.jpg` mostrando a imagem e a aba Network sem uma nova chamada de salvamento.

## 4. Testar atualizacao sem trocar a foto

1. Edite o nome ou a bio.
2. Nao selecione uma nova imagem.
3. Clique em `Salvar alterações`.
4. Na aba Network, confirme uma requisicao:

```text
PUT http://localhost:3000/api/profile/me
```

5. Confirme o status `200`.
6. Confirme a mensagem `Perfil atualizado com sucesso.`.
7. Confirme que a foto anterior continua aparecendo.

### Teste equivalente no Postman

Envie uma requisicao `PUT` para:

```text
http://localhost:3000/api/profile/me
```

Headers:

```text
Authorization: Bearer SEU_TOKEN
```

Body: `form-data`

```text
fullName = Novo Nome
bio = Minha nova bio
```

Nao defina manualmente o header `Content-Type` no Postman; o cliente deve criar o boundary automaticamente.

## 5. Testar atualizacao com foto

1. Altere o nome ou a bio.
2. Selecione uma nova imagem.
3. Clique em `Salvar alterações`.
4. Na aba Network, abra a requisicao `PUT /api/profile/me`.
5. Confirme o header parecido com:

```text
Content-Type: multipart/form-data; boundary=------------------------...
```

6. Confirme o status `200`.
7. Confirme que a nova imagem aparece depois do salvamento.

Para a entrega, salve um print como `upload-multipart.jpg`.

No Postman, use Body > form-data:

```text
fullName: Novo Nome
bio: Bio atualizada
photo: arquivo do tipo File
```

## 6. Testar o link da Navbar

1. Faca login.
2. Volte para a Landing Page usando a navegacao da aplicacao.
3. Confirme que o link `Meu perfil` aparece na Navbar.
4. Clique nele para chegar ao perfil sem digitar a URL manualmente.

Para a entrega, salve um print como `navbar-link-perfil.jpg`.

## 7. Testar a API com cURL

Substitua `SEU_TOKEN` por um token real.

### GET do perfil

```powershell
curl.exe -i http://localhost:3000/api/profile/me `
  -H "Authorization: Bearer SEU_TOKEN"
```

Esperado: status `200`.

### GET do arquivo padrão

```powershell
curl.exe -i http://localhost:3000/uploads/profiles/default-profile.png
```

Esperado: status `200`.

### PUT sem foto

```powershell
curl.exe -i -X PUT http://localhost:3000/api/profile/me `
  -H "Authorization: Bearer SEU_TOKEN" `
  -F "fullName=Nome Atualizado" `
  -F "bio=Bio atualizada no teste"
```

Esperado: status `200`, mantendo a foto atual.

### PUT com foto

```powershell
curl.exe -i -X PUT http://localhost:3000/api/profile/me `
  -H "Authorization: Bearer SEU_TOKEN" `
  -F "fullName=Nome Atualizado" `
  -F "bio=Bio com foto nova" `
  -F "photo=@C:\caminho\para\uma\imagem.jpg"
```

Esperado: status `200`, novo nome de arquivo em `public/uploads/profiles/` e foto antiga personalizada removida.

### Bio acima do limite

```powershell
$bioLonga = '1234567890' * 17
curl.exe -i -X PUT http://localhost:3000/api/profile/me `
  -H "Authorization: Bearer SEU_TOKEN" `
  -F "fullName=Nome" `
  -F "bio=$bioLonga"
```

Esperado: status `400` e mensagem informando que a bio deve ter no maximo 160 caracteres.

Para a entrega, faça um print de cada comando e sua resposta na pasta `Docs/atividade05/`.

## 8. Observacoes importantes

- O campo do arquivo precisa se chamar `photo`.
- O limite da bio e 160 caracteres, definido por `BIO_MAX`.
- O `Content-Type` global do Axios continua `application/json`.
- Apenas `updateProfile(formData)` sobrescreve o tipo para `multipart/form-data`.
- Nao coloque `node_modules` nos arquivos ZIP da entrega.
